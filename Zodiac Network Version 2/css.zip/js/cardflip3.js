const cards3 = document.querySelector(".card__inners3");

cards3.addEventListener("click", function (e) {
  cards3.classList.toggle('is-flipped');
});


